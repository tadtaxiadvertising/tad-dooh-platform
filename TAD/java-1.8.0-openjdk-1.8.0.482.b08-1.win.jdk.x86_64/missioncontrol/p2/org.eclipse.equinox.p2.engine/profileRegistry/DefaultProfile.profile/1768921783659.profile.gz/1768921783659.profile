<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1768921783659'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='C:\cygwin64\tmp\ojdkbuild\upstream\jmc\target\products\org.openjdk.jmc\win32\win32\x86_64'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='C:\cygwin64\tmp\ojdkbuild\upstream\jmc\target\products\org.openjdk.jmc\win32\win32\x86_64'/>
  </properties>
</profile>
